import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { FloatingChatButton } from '@/components/floating-chat-button'

export default function PollutionPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-1">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-8">Ô Nhiễm Môi Trường</h1>

          <div className="bg-red-50 border-l-4 border-red-500 p-6 mb-12 rounded">
            <h2 className="text-2xl font-bold text-red-700 mb-2">⚠️ Thực Trạng Hiện Nay</h2>
            <p className="text-gray-700">
              Ô nhiễm môi trường đã trở thành một trong những thách thức lớn nhất của thế kỷ 21. Hàng triệu tấn khí thải được phát tán vào không khí mỗi năm, làm suy giảm chất lượng không khí và gây hại cho sức khỏe công cộng.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-12">
            <div>
              <h3 className="text-2xl font-bold text-primary mb-4">🌫️ Ô Nhiễm Không Khí</h3>
              <p className="text-gray-700 mb-4 leading-relaxed">
                Ô nhiễm không khí là do các hoạt động công nghiệp, giao thông vận tải và sử dụng năng lượng hóa thạch. Nó gây ra các bệnh hô hấp, tim mạch và có thể dẫn đến tử vong sớm.
              </p>
              <ul className="list-disc pl-6 text-gray-700 space-y-2">
                <li>4 triệu ca tử vong sớm mỗi năm do ô nhiễm không khí</li>
                <li>PM2.5 là chất ô nhiễm chính trong các thành phố lớn</li>
                <li>Ảnh hưởng đặc biệt đến trẻ em và người cao tuổi</li>
              </ul>
            </div>
            <div className="bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg p-8 flex items-center justify-center">
              <div className="text-center">
                <div className="text-7xl mb-4">🌫️</div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-12">
            <div className="bg-gradient-to-br from-blue-100 to-cyan-100 rounded-lg p-8 flex items-center justify-center">
              <div className="text-center">
                <div className="text-7xl mb-4">💧</div>
              </div>
            </div>
            <div>
              <h3 className="text-2xl font-bold text-primary mb-4">💧 Ô Nhiễm Nước</h3>
              <p className="text-gray-700 mb-4 leading-relaxed">
                Nước sạch là tài sản quý giá. Ô nhiễm nước do công nghiệp, nông nghiệp và chất thải gia đình làm suy giảm chất lượng nước và ảnh hưởng đến hàng triệu người.
              </p>
              <ul className="list-disc pl-6 text-gray-700 space-y-2">
                <li>2 tỷ người truy cập vào nước uống không an toàn</li>
                <li>Ô nhiễm nhựa trong đại dương đe dọa đến sự sống biển</li>
                <li>Các hóa chất từ nông nghiệp oxit hóa các con sông</li>
              </ul>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-12">
            <div>
              <h3 className="text-2xl font-bold text-primary mb-4">🌍 Thay Đổi Khí Hậu</h3>
              <p className="text-gray-700 mb-4 leading-relaxed">
                Khí thải nhà kính từ các hoạt động con người đang làm nóng lên hành tinh, dẫn đến mực nước biển dâng cao, thời tiết cực đoan, và mất sinh học.
              </p>
              <ul className="list-disc pl-6 text-gray-700 space-y-2">
                <li>Nhiệt độ toàn cầu tăng 1.1°C kể từ thời kỳ tiền công nghiệp</li>
                <li>CO2 trong không khí ở mức cao nhất trong 3 triệu năm</li>
                <li>Cần hành động khẩn cấp để giới hạn sự nóng lên</li>
              </ul>
            </div>
            <div className="bg-gradient-to-br from-orange-100 to-yellow-100 rounded-lg p-8 flex items-center justify-center">
              <div className="text-center">
                <div className="text-7xl mb-4">🌍</div>
              </div>
            </div>
          </div>

          <div className="bg-primary text-white rounded-lg p-8">
            <h3 className="text-2xl font-bold mb-4">Tác Hại Của Ô Nhiễm Môi Trường</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-bold mb-2">Tác Động Sức Khỏe:</h4>
                <ul className="list-disc pl-6 space-y-1 text-sm">
                  <li>Bệnh hô hấp và tim mạch</li>
                  <li>Ung thư</li>
                  <li>Vô sinh</li>
                  <li>Rối loạn phát triển ở trẻ em</li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold mb-2">Tác Động Sinh Thái:</h4>
                <ul className="list-disc pl-6 space-y-1 text-sm">
                  <li>Mất đa dạng sinh học</li>
                  <li>Suy thoái đất đai</li>
                  <li>Mất rừng</li>
                  <li>Sụt kỳ san hô</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <FloatingChatButton />
    </div>
  )
}
