'use client'

import { useEffect } from 'react'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'

export default function ChatbotPage() {
  useEffect(() => {
    // Load Botpress script
    const script = document.createElement('script')
    script.src = 'https://cdn.botpress.cloud/webchat/v3.5/shareable.html'
    script.async = true
    document.body.appendChild(script)
  }, [])

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-1">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">Chatbot Tư Vấn Môi Trường</h1>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl text-pretty">
            Trò chuyện với trợ lý AI thông minh của chúng tôi để nhận lời khuyên cá nhân hóa về sống xanh và bảo vệ môi trường.
          </p>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Features */}
            <div className="lg:col-span-1 space-y-6">
              <div className="bg-secondary rounded-lg p-6">
                <div className="text-4xl mb-3">💬</div>
                <h3 className="text-xl font-bold text-primary mb-2">Tư Vấn 24/7</h3>
                <p className="text-gray-700 text-sm">
                  Nhận tư vấn bất kỳ lúc nào về các vấn đề môi trường.
                </p>
              </div>

              <div className="bg-secondary rounded-lg p-6">
                <div className="text-4xl mb-3">🎯</div>
                <h3 className="text-xl font-bold text-primary mb-2">Cá Nhân Hóa</h3>
                <p className="text-gray-700 text-sm">
                  Các lời khuyên được cá nhân hóa dựa trên nhu cầu của bạn.
                </p>
              </div>

              <div className="bg-secondary rounded-lg p-6">
                <div className="text-4xl mb-3">🚀</div>
                <h3 className="text-xl font-bold text-primary mb-2">Hỗ Trợ Ngay Lập Tức</h3>
                <p className="text-gray-700 text-sm">
                  Nhận câu trả lời ngay lập tức cho câu hỏi của bạn.
                </p>
              </div>
            </div>

            {/* Chat Area */}
            <div className="lg:col-span-2 bg-white rounded-lg border-2 border-gray-200 overflow-hidden min-h-96 flex items-center justify-center">
              <div className="text-center p-8">
                <div className="text-6xl mb-4">🤖</div>
                <h2 className="text-2xl font-bold text-primary mb-4">Chatbot của Chúng Tôi</h2>
                <p className="text-gray-600 mb-6">
                  Chatbot AI thông minh sẽ được tải dưới đây. Vui lòng chờ một chút...
                </p>
                <div className="inline-block px-6 py-3 bg-primary text-white font-semibold rounded-lg hover:bg-accent transition-colors">
                  Hoặc nhấp vào nút "Chat với trợ lý AI" ở góc dưới bên phải
                </div>
              </div>
            </div>
          </div>

          {/* Question Examples */}
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-primary mb-6">Bạn Có Thể Hỏi Chatbot Về:</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                '💡 Cách tiết kiệm năng lượng tại nhà',
                '♻️ Làm thế nào để bắt đầu tái chế',
                '🚴 Cách giảm lượng khí thải carbon',
                '🥬 Thực phẩm nào là bền vững nhất',
                '🌍 Thực trạng ô nhiễm môi trường',
                '🌱 Cách trồng rau tại nhà',
              ].map((question, index) => (
                <div
                  key={index}
                  className="bg-gradient-to-r from-primary to-accent text-white rounded-lg p-4 hover:shadow-lg transition-shadow"
                >
                  {question}
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
